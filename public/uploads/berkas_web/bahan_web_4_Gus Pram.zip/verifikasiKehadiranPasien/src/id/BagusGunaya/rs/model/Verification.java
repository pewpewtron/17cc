/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package id.BagusGunaya.rs.model;

/**
 *
 * @author User-PC
 */
public class Verification {
    private String uniqueCode;
    private String registrationid;
    private int click;
    
    public Verification (){
    }
    
    public Verification (String uniqueCode){
        this.uniqueCode = uniqueCode;
    }

    public void setUniqueCode(String uniqueCode){
        this.uniqueCode = uniqueCode;
    }
    
    public String getUniqueCode(){
        return this.uniqueCode;
    }
      
    public void setRegistrationid(String registrationid){
        this.registrationid = registrationid;
    }
    public String getRegistrationid(){
        return this.registrationid;
    }
    
    public void setClick(int click){
        this.click = click;
    }
    
    public int getClick(){
        return this.click;
    }
    
}
