/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package id.BagusGunaya.rs.model;

/**
 *
 * @author User-PC
 */
public class DataPatient {
    private String patientname;
    private int age;
    private String gender;
    private String bloodtype;
    private String category;
    private String checkup;
    
    public void setPatientname(String patientname){
        this.patientname = patientname;
    }
    
    public String getPatientname(){
        return this.patientname;
    }
    
    public void setAge(int age){
        this.age = age;
    }
    
    public int getAge(){
        return this.age;
    }
    
    public void setGender(String gender){
        this.gender = gender;
    }
    
    public String getGender(){
        return this.gender;
    }
    
    public void setBloodtype(String bloodtype){
        this.bloodtype = bloodtype;
    }
    
    public String getBloodtype(){
        return this.bloodtype;
    }
    
    public void setCategory(String category){
        this.category = category;
    }
    
    public String getCategory(){
        return this.category;
    }
    
    public void setCheckup(String checkup){
        this.checkup = checkup;
    }
    
    public String getCheckup(){
        return this.checkup;
    }
    
}
