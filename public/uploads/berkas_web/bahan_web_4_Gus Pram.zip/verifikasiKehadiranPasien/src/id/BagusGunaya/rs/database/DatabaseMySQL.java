/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package id.BagusGunaya.rs.database;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


/**
 *
 * @author User-PC
 */
public class DatabaseMySQL {
    private static Connection connection = null;
    
    public static Connection getConnection() throws Exception{
        if(connection == null){
            try{
                Class.forName("com.mysql.jdbc.Driver");
                connection = DriverManager.getConnection("jdbc:mysql://localhost/db_rs","root","");
            }catch(Exception e){
                e.printStackTrace();
            }
            
        }
        return connection;
    }
    
    public static boolean isConnect(){
        try{
            if(getConnection()==null){
                JOptionPane.showMessageDialog(null, "Koneksi ke Database Gagal!", "Eror", JOptionPane.ERROR_MESSAGE);
                JOptionPane.showMessageDialog(null, "Pastikan Server Database Sudah Aktif", "Information", JOptionPane.INFORMATION_MESSAGE );
                return false;
            }
        }catch(Exception ex){
                Logger.getLogger(DatabaseMySQL.class.getName()).log(Level.SEVERE, null, ex);
        }
        return true;
        }
}
