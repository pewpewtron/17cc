/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package id.BagusGunaya.rs.controller;

import id.BagusGunaya.rs.dao.VerifyPatientDAO;
import id.BagusGunaya.rs.dao.VerifyPatientDAOMySQL;
import id.BagusGunaya.rs.model.Verification;
import id.BagusGunaya.rs.model.DataPatient;
import id.BagusGunaya.rs.model.QueryState;
import java.util.Observable;

/**
 *
 * @author User-PC
 */
public class VerifyPatientController extends Observable{
    private VerifyPatientDAO dao = new VerifyPatientDAOMySQL();
    private QueryState querystate;
    
    public void setDAO(VerifyPatientDAO d){
        dao = d;
    }
    
    public void manipulate(Verification verify, DataPatient patient, QueryState c){
        boolean result = false;
        this.querystate = c;
        
        switch(c){
            case SELECT:
                result = dao.select(verify, patient);
                break;
            case UPDATE:
                result = dao.update(verify);
                break;
            case INSERT:
                result = dao.insert(verify);
                break;
        }
        
        setChanged();
        if(result){
            notifyObservers(patient);
        }else{
            notifyObservers();
        }      
    }
    
    public QueryState getQueryState(){
        return querystate;
    }
}
