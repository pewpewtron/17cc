/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package id.BagusGunaya.rs.dao;

import id.BagusGunaya.rs.model.Verification;
import id.BagusGunaya.rs.model.DataPatient;
import id.BagusGunaya.rs.database.DatabaseMySQL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author User-PC
 */
public class VerifyPatientDAOMySQL implements VerifyPatientDAO{

    @Override
    public boolean select(Verification verify, DataPatient patient) {
        String selectSQL = "SELECT registrationid, patientname, 2017-YEAR(dateofbirth) AS AGE, "
                        + "gender, bloodtype, category, datetimecheckup FROM patient " +
                        "INNER JOIN registration ON registration.`patientid`=patient.`patientid` " +
                        "WHERE uniquecode=? AND status=2 ORDER BY registrationid ASC LIMIT 1;";
        try{
            PreparedStatement statement = DatabaseMySQL.getConnection().prepareStatement(selectSQL);
            
            statement.setString(1, verify.getUniqueCode());
            
            ResultSet rs = statement.executeQuery();
            while(rs.next()) {
                verify.setRegistrationid(rs.getString("registrationid"));
                patient.setPatientname(rs.getString("patientname"));
                patient.setAge(rs.getInt("AGE"));
                patient.setGender(rs.getString("gender"));
                patient.setBloodtype(rs.getString("bloodtype"));
                patient.setCategory(rs.getString("category"));
                patient.setCheckup(rs.getString("datetimecheckup"));
            }
            statement.close();
        }catch(Exception e){
            System.out.print("Kode Salah!");
            System.out.print(e.getMessage());
        }
        return true;
    }
    

    @Override
    public boolean update(Verification verify) {
        String updateSQL = "UPDATE registration SET status=1 WHERE registrationid=?";
        
        try{
            PreparedStatement statement = DatabaseMySQL.getConnection().prepareStatement(updateSQL);
            
            statement.setString(1, verify.getRegistrationid());
                int rowsUpdated = statement.executeUpdate();
                if (rowsUpdated > 0) {
                    System.out.println("\nData Tervalidasi\n\n");
                }
        }catch(Exception e){
            System.out.print(e.getMessage());
        }
      return true;
    }

    @Override
    public boolean insert(Verification verify) {
        String insertSQL = "INSERT INTO queue(registrationid) VALUES(?);";
        
        try{
            PreparedStatement statement = DatabaseMySQL.getConnection().prepareStatement(insertSQL);
            
            statement.setString(1, verify.getRegistrationid());
            int rowInserted = statement.executeUpdate();
                if (rowInserted > 0){
                    System.out.println("Data berhasil ditambahkan");
            }
        }catch(Exception e){
            System.out.print(e.getMessage());
        }
        return false;
    }
    
}
